# Storyboard Podcast — EduTech Avionik

> **Transformasi Pengajaran Avionik Melalui Teknologi Pendidikan**  
> GGGP6223 Penerbitan Video Pendidikan · UKM Sarjana Teknologi Pendidikan

Storyboard interaktif podcast pendidikan dalam format HTML standalone — boleh dibuka terus dalam browser, tanpa server, tanpa internet.

## Demo Langsung

👉 **[Buka Storyboard](https://[USERNAME].github.io/[REPO-NAME])**  
*(Kemas kini URL selepas deploy — gantikan `[USERNAME]` dan `[REPO-NAME]`)*

---

## Kandungan

| Scene | Segmen | Masa |
|-------|--------|------|
| 01 | Intro | 0:00 – 3:00 |
| 02 | Pengenalan Pakar | 3:00 – 12:00 |
| 03 | Perkembangan Terkini | 12:00 – 22:00 |
| 04 | Kelebihan Teknologi | 22:00 – 32:00 |
| 05 | Cabaran & Halangan | 32:00 – 42:00 |
| 06 | Contoh Berkesan | 42:00 – 52:00 |
| 07 | Nasihat & Pandangan | 52:00 – 57:00 |
| 08 | Penutup | 57:00 – 60:00 |

Setiap scene mengandungi:
- **Gambar storyboard** — ilustrasi SVG 16:9 dengan viewfinder, grid rule-of-thirds, overlay khas
- **Saiz syot** — WS / MS / MCU / CU
- **Sudut & pergerakan kamera** — push-in, dolly-out, cutaway, PIP
- **Nota komposisi** — rule of thirds, depth of field, lower-third, CTA
- **Skrip dialog penuh** — MODERATOR (bertanya) + PAKAR (menjawab)

## Cara Guna

```
Klik tab scene → navigasi dengan butang atau ← → keyboard
Butang Cetak → PDF / hardcopy setiap scene
```

## Fail

```
index.html    ← satu fail, semua kandungan (standalone, no dependencies)
README.md
```

## Stack

- HTML5 + CSS3 + Vanilla JS (zero dependencies)
- SVG inline untuk gambar storyboard
- Boleh deploy ke GitHub Pages, Netlify, Vercel — mana-mana static host
